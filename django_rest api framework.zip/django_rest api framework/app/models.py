from django.db import models


#company model

class Company(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=50)
    location=models.CharField(max_length=70)
    about=models.TextField()
    type=models.CharField(max_length=100,choices=(('IT','IT'),
                                                  ('Non IT','Non IT'),
                                                  ('Mobiles Phones','Mobiles Phones')))
    
    
    added_date=models.DateTimeField(auto_now_add=True)
    active=models.BooleanField(default=True)
    
    #override method those who want to see
    def __str__(self):
        return self.name +'-->'+ self.location
    
#employees models

class Employee(models.Model):
    emp_id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=50)
    email=models.EmailField(max_length=50)
    address=models.CharField(max_length=200)
    phone=models.CharField(max_length=10)
    about=models.TextField()
    position=models.CharField(max_length=50,choices=(('Manager','Manager'),
                                                  ('Software developer','Software developer'),
                                                  ('Project leader','project leader'),
                                                  ('HR','HR'),
                                                  ('project delivery head','project delivery head')))
    

    added_date=models.DateTimeField(auto_now_add=True)
    company_details=models.ForeignKey(Company, on_delete=models.CASCADE)
    
    
    
    