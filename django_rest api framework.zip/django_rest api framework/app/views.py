from django.shortcuts import render
from django.http import HttpResponse,response,request,JsonResponse
from rest_framework import viewsets
from app.serializers import CompanySerializer,EmployeeSerializer
from app.models import Company,Employee
from rest_framework.decorators import action



class CompanyViewSet(viewsets.ModelViewSet):
    queryset=Company.objects.all()
    serializer_class = CompanySerializer
    
    #custum urls
    @action(detail=True,methods=['get'])
    def employees(self,request,pk=None):
        print("get employees of ",pk, "company")
        pass
    
class EmployeeViewSet(viewsets.ModelViewSet):
    queryset=Employee.objects.all()
    serializer_class = EmployeeSerializer
    