from django.urls import path,include
from django.contrib import admin

from rest_framework import routers
from app.views import CompanyViewSet,EmployeeViewSet

router=routers.DefaultRouter()
router.register(r'companies',CompanyViewSet)
router.register(r'Employee',EmployeeViewSet)


urlpatterns = [
    
    path('', include(router.urls)),
    
]
