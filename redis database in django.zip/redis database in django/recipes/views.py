from django.http import HttpResponse
from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import ListView, View
from django.core.cache import cache
from .models import Recipes

class RecipesView(ListView):
    model = Recipes
    template_name = "recipes.html"
    context_object_name = "recipes"

class RecipeView(View):
    template_name="recipie.html"
    
    def get(self, request, *args, **kwargs):
        recipe_id = kwargs['pk']

        if cache.get(recipe_id):
            recipe = cache.get(recipe_id)
            print("hit the cache")
        else:
            try:
                recipe = Recipes.objects.get(pk=recipe_id)
                cache.set(recipe_id, recipe)
                print("hit the db")
            except Recipes.DoesNotExist:  
                return HttpResponse("This recipe does not exist")
            
        context={
            "recipe":recipe,
        }

        return render(request,self.template_name,context)



