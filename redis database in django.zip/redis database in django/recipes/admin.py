from django.contrib import admin

from . import models

from .models import*

admin.site.register(Category)
admin.site.register(Recipes)

